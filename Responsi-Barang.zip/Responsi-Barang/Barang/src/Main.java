/*
Raden Rara Lydia Devina Syantasyacitta
123190086
Plug IF-C
*/
import controller.MenuControl;

public class Main {
    public static void main(String[] args){
        MenuControl menu= new MenuControl(); //implimentasi polymorphysm
        menu.openMenu();
    }
}
