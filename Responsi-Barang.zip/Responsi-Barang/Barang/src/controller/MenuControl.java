package controller;

import view.ViewMenu;

public class MenuControl {
    public void openMenu(){
        new ViewMenu();
}
}
